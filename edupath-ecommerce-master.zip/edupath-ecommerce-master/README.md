![Thumbnail template web ecommerce 65](https://github.com/user-attachments/assets/d65b29bc-ac50-4b4b-9a30-34db2386d916)
